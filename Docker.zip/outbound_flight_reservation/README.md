# outbound_flight_reservation
Full stack example flight reservation website. Users can view flights, book flights, sign in and out, create an account. The flights are managed in a database and the website uses Node.js
