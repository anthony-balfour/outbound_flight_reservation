# flight-reserve-backend
Full stack example flight reservation website.<br>
I wireframed the design and created the API endpoints.
Users can view flights, book flights, sign in and out, create an account, look at flight deals, and toggle through different view for flights (list vs grid).<br> 
The website data is managed through an SQLite database. <br>
The backend is managed with node.js. <br>
Clicking flight deals brings users to an expanded view of the chosen flight. <br>
The app mobile-responsive across all pages
The code is fully documented

Example login/pw
Login: calvin
Password: gotobed
